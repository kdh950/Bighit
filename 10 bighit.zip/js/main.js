$(document).ready(function(){
    
    // 햄버거버튼 클릭 - .nav_mo 보인다
    $("header .header_ham").click(function(){
        $(".nav_mo").fadeIn();
    });

    $(".btn_close").click(function(){
        $(".nav_mo").fadeOut();
    });

    // 모바일 상태에서 .nav_mo가 보이는 상황에서 화면이 넓어지면 style이 그대로 남아있는 상태가 되는 걸 방지
    $(window).resize(function(){
        const w = $(window).width();    // 브라우저의 가로 길이를 변수w에 넣어준다
        if( w > 768){
            $(".nav_mo").removeAttr("Style");
        }
    })
});      